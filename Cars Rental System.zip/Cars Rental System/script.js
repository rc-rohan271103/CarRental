let currentRole = "";

function showLogin(role) {
    currentRole = role;
    document.getElementById('role-selection').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('login-title').innerText = role === 'user' ? 'User Login' : 'Business Owner Login';
}

function login() {
    const id = document.getElementById('id-input').value;
    const name = document.getElementById('name-input').value;
    const pwd = document.getElementById('password-input').value;

    // Mock validation (replace with real validation)
    if (id && name && pwd) {
        document.getElementById('login-form').style.display = 'none';
        if (currentRole === 'user') {
            document.getElementById('user-menu').style.display = 'block';
        } else if (currentRole === 'owner') {
            document.getElementById('owner-menu').style.display = 'block';
        }
    } else {
        alert("Please fill all fields!");
    }
}

function logout() {
    document.getElementById('user-menu').style.display = 'none';
    document.getElementById('owner-menu').style.display = 'none';
    document.getElementById('role-selection').style.display = 'block';
}
