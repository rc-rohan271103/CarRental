import tkinter as tk
from tkinter import messagebox, simpledialog
import pandas as pd
import matplotlib.pyplot as plt

def addUser():
    uid = simpledialog.askstring("Add User", "Enter User ID:")
    uname = simpledialog.askstring("Add User", "Enter User Name:")
    pwd = simpledialog.askstring("Add User", "Enter Password:")

    try:
        udf = pd.read_csv("Users.csv")
    except FileNotFoundError:
        udf = pd.DataFrame(columns=["User ID", "User Name", "Password"])

    if uid in udf["User ID"].values:
        messagebox.showerror("Error", "User ID already exists.")
        return

    new_user = pd.DataFrame([[uid, uname, pwd]], columns=udf.columns)
    udf = pd.concat([udf, new_user], ignore_index=True)
    udf.to_csv("Users.csv", index=False)
    messagebox.showinfo("Success", "User added successfully.")

def deleteUser():
    uid = simpledialog.askstring("Delete User", "Enter User ID to delete:")
    try:
        udf = pd.read_csv("Users.csv")
        udf = udf.drop(udf[udf["User ID"] == uid].index)
        udf.to_csv("Users.csv", index=False)
        messagebox.showinfo("Success", "User deleted successfully.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

def showUsers():
    try:
        udf = pd.read_csv("Users.csv")
        messagebox.showinfo("Users", udf.to_string())
    except Exception as e:
        messagebox.showerror("Error", str(e))

def addNewCar():
    carno = simpledialog.askinteger("Add Car", "Enter Car Number:")
    carname = simpledialog.askstring("Add Car", "Enter Car Name:")
    brand = simpledialog.askstring("Add Car", "Enter Brand:")
    branch = simpledialog.askstring("Add Car", "Enter Branch:")
    fueltype = simpledialog.askstring("Add Car", "Enter Fuel Type:")
    cost = simpledialog.askinteger("Add Car", "Enter Cost per day:")
    category = simpledialog.askstring("Add Car", "Enter Category:")

    try:
        cdf = pd.read_csv("Cars.csv")
    except FileNotFoundError:
        cdf = pd.DataFrame(columns=["Car No.", "Car Name", "Brand", "Branch", "Fuel Type", "Cost", "Category"])

    if carno in cdf["Car No."].values:
        messagebox.showerror("Error", "Car Number already exists.")
        return

    new_car = pd.DataFrame([[carno, carname, brand, branch, fueltype, cost, category]], columns=cdf.columns)
    cdf = pd.concat([cdf, new_car], ignore_index=True)
    cdf.to_csv("Cars.csv", index=False)
    messagebox.showinfo("Success", "Car added successfully.")

def showCars():
    try:
        cdf = pd.read_csv("Cars.csv")
        messagebox.showinfo("Cars", cdf.to_string())
    except Exception as e:
        messagebox.showerror("Error", str(e))

def showCharts():
    df = pd.read_csv("Cars.csv")
    df = df[["Car Name", "Cost"]]
    df.plot(x="Car Name", y="Cost", kind="bar")
    plt.xlabel("Car Name")
    plt.ylabel("Cost per Day")
    plt.show()

# Create main window
root = tk.Tk()
root.title("Luxury Car Rentals")

# Create buttons
btn_add_user = tk.Button(root, text="Add User", width=20, command=addUser)
btn_delete_user = tk.Button(root, text="Delete User", width=20, command=deleteUser)
btn_show_users = tk.Button(root, text="Show Users", width=20, command=showUsers)
btn_add_car = tk.Button(root, text="Add Car", width=20, command=addNewCar)
btn_show_cars = tk.Button(root, text="Show Cars", width=20, command=showCars)
btn_show_charts = tk.Button(root, text="View Charts", width=20, command=showCharts)

# Place buttons
btn_add_user.pack(pady=5)
btn_delete_user.pack(pady=5)
btn_show_users.pack(pady=5)
btn_add_car.pack(pady=5)
btn_show_cars.pack(pady=5)
btn_show_charts.pack(pady=5)

root.mainloop()
